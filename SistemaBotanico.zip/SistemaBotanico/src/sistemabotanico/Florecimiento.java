
package sistemabotanico;


public enum Florecimiento {

PRIMAVERA,
VERANO,
OTOÑO,
INVIERNO;

}
