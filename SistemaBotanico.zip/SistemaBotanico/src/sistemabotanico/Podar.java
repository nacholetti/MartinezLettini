
package sistemabotanico;


public interface Podar {
    
    public abstract boolean poderPlantas();
    
}
